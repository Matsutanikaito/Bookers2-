# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'c1624fda72810855d7dc93b7ba77c4240b7484608a9de5b617650c3ce154553d358b8b15396fb9c9fdd38323cfa88ca2b4af02eaed9880267e22818b169a83df'