class BooksController < ApplicationController
  def new
     @book = Book.new
  end

  def create
  @book = Book.new(book_params)
  @book.user_id = current_user.id  # 投稿したユーザーに、ログインユーザーを紐づける
  if @book.save
      # 成功したとき
      flash[:notice] = "You have created book successfully."
   redirect_to book_path(@book)
  else
    @books = Book.all
    @user = current_user
      # 失敗したとき
    render :index
      
  end
 end
    

  def index
    @books = Book.all
    @user = current_user
    @book = Book.new
  end

  def show
    @book = Book.find(params[:id]) 
    @user = @book.user
    @book_new = Book.new  # 投稿用（views/books/show.html.erbの form_withではこの @book_newを参照する）
  end
  
  def edit
    @book = Book.find(params[:id]) 
    if @book.user == current_user
        render "edit"
    else
        redirect_to books_path
    end
  end
   
  
  def destroy
   @book = Book.find(params[:id])
    if @book.destroy
      flash[:notice]="Book was successfully destroyed."
      redirect_to books_path
    end
  end
  
  def update
    @book = Book.find(params[:id])
    @book.user_id = current_user.id
    if @book.update(book_params)
      flash[:notice]="Book was successfully updated."
      redirect_to book_path(@book.id)
    else
      render :edit
    end
  end
  
  
  private
  def book_params
    params.require(:book).permit(:title,:body)
  end
end

