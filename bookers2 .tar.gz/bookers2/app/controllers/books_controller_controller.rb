class BooksControllerController < ApplicationController
  def new
  end

  def create
    book = Book.new(book_params)
    book.save
    binding.pry
    redirect_to book_path(book.id)
  end

  def index
    @books = book.all
    
  end

  def show
     @book = Book.find(params[:id])  
  end

  def destroy
  end
end