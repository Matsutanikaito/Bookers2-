class UserController < ApplicationController
  def new
  end
end
